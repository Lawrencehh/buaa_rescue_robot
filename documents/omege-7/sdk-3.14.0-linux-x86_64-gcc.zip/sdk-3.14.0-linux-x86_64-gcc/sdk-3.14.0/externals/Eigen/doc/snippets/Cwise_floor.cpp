ArrayXd v = ArrayXd::LinSpaced(7,-2,2);
cout << v << endl << endl;
cout << floor(v) << endl;
